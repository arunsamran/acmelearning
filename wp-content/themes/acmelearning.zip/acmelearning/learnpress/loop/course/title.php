<?php
/**
 * @author        ThimPress
 * @package       LearnPress/Templates
 * @version       1.0
 */

defined( 'ABSPATH' ) || exit();
?>
<h3><a href="<?php echo get_the_permalink(); ?>"><?php the_title(); ?></a></h3>